﻿
namespace Business.Service
{
    public class AuthService
    {

    }
}
